NOTE - These scripts were graciously donated to the LOINC community by Frederik Lindberg. 

This directory includes very rudimentary scripts for importing the LOINC codes
into a Postgres database. These scripts are very basic and should not be used 
in a production environment. They are provided as a starting point to show 
one method that can be used to load the LOINC data.
 
It is highly recommended that you consult with your database administrator
before attempting to run these scripts or load these data.

It is assumed that you are working in a Unix environment and have the 
Postgres software installed on your computer.

The following uses psql in the simplest case where the database is local
and writable to the current user without password. For other cases,
please add the approptiate psql options. 

1. Change to this directory.
2. Create a database loinc.

   $ psql -c 'create database loinc';

3. Create the schema:

   $ psql loinc < PostgresDdl.sql

4. Load the data

   $ psql loinc < PostgresLoader.sql

